ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Base Entity"
ENT.Author = "Wolf"
ENT.Spawnable = true
ENT.AdminSpawnable = false
ENT.Category = "nChanted: Chemistry"