ENT.Type = "anim"
ENT.Base = "chem_base"
ENT.PrintName = "Stove"
ENT.Author = "Wolf"
ENT.Spawnable = true
ENT.AdminSpawnable = false
ENT.Category = "nChanted: Equipment"
